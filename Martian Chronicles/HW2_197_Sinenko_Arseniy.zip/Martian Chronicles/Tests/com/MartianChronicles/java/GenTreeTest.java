package com.MartianChronicles.java;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GenTreeTest {

    @Test
    void makeMartianConservative() {
        String expected = "ConservatorMartian(String:Jack)\n" +
                "    ConservatorMartian(String:Kelvin)\n" +
                "        ConservatorMartian(String:Miky)\n" +
                "            ConservatorMartian(String:Voyage)\n" +
                "            ConservatorMartian(String:Keka)\n" +
                "        ConservatorMartian(String:Lola)\n" +
                "    ConservatorMartian(String:Marvin)\n";
        InnovatorMartian<String> Jack = new InnovatorMartian<String>("Jack");
        InnovatorMartian<String> Kelvin = new InnovatorMartian<String>("Kelvin");
        InnovatorMartian<String> Marvin = new InnovatorMartian<String>("Marvin");
        InnovatorMartian<String> Miky = new InnovatorMartian<String>("Miky");
        InnovatorMartian<String> Lola = new InnovatorMartian<String>("Lola");
        InnovatorMartian<String> Voyage = new InnovatorMartian<String>("Voyage");
        InnovatorMartian<String> Keka = new InnovatorMartian<String>("Keka");
        Jack.addChild(Kelvin);
        Jack.addChild(Marvin);
        Kelvin.addChild(Miky);
        Kelvin.addChild(Lola);
        Miky.addChild(Voyage);
        Miky.addChild(Keka);
        GenTree<String> tree = new GenTree<String>(Jack);
        tree.MakeMartianConservative(Jack);
        assertEquals(expected, tree.toString());
    }

    @Test
    void fromStringToobject() {
        String input = "InnovatorMartian(String:Jack)\n" +
                "    InnovatorMartian(String:Kelvin)\n" +
                "        InnovatorMartian(String:Miky)\n" +
                "            InnovatorMartian(String:Voyage)\n" +
                "            ConservatorMartian(String:Keka)\n" +
                "        InnovatorMartian(String:Lola)\n" +
                "    InnovatorMartian(String:Marvin)\n";
        String expected = "ConservatorMartian(String:Jack)\n" +
                "    ConservatorMartian(String:Kelvin)\n" +
                "        ConservatorMartian(String:Miky)\n" +
                "            ConservatorMartian(String:Voyage)\n" +
                "            ConservatorMartian(String:Keka)\n" +
                "        ConservatorMartian(String:Lola)\n" +
                "    ConservatorMartian(String:Marvin)\n";
        GenTree<String> tree = new GenTree<String>(input);
        assertEquals(expected, tree.toString());
    }
}